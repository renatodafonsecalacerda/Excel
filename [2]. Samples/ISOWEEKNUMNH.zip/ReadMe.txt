
Function ISOWeekNum(Given_Date As Date)

To use the ISOWeekNum add-in:

1. Install the add-in (Tools>Add-ins)

2. Type a date in a worksheet cell, e.g. cell A1.

3. To determine the ISO week number, in another cell, enter the following formula:

    =ISOWeekNum(A1)